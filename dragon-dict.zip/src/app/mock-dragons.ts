import {Dragon} from './dragon';

export const DRAGONS: Dragon[] = [

];