export interface Dragon {
    id: number;
    name: string;
    type: string;
    size: number;
    description :string;
    picurl: string;
}